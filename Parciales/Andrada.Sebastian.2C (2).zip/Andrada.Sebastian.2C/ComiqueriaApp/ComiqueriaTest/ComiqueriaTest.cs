﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ComiqueriaLogic;

namespace ComiqueriaTest
{
    [TestClass]
    public class ComiqueriaTests
    {
        [TestMethod]
        public void PrecioMasIvaDeUnaVenta()
        {
            double expected = 121f;
            double actual;

            actual = Venta.CalcularPrecioFinal(100, 1);

            Assert.AreEqual(expected, actual);
        }
    }
}
