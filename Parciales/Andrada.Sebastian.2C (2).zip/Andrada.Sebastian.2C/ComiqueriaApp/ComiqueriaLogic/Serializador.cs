﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace ComiqueriaLogic
{
    public static class Serializador<T>
    {
        static Serializador() { }

        public static bool SerializarXML(T datos, string archivo)
        {
            bool resultado = false;
            XmlTextWriter w = new XmlTextWriter(archivo, Encoding.UTF8);
            XmlSerializer ser = new XmlSerializer(typeof(T));
            try
            {
                ser.Serialize(w, datos);
                resultado = true;
            }
            catch (ArgumentException e)
            {
                throw new Exception("error al intentar serealizar", e);
            }
            catch (Exception e)
            {
                throw new Exception("Ocurrio un error, contacte al administrador");
            }
            finally
            {
                w.Close();
            }
            return resultado;
        }

        public static bool DeserealizarXML(string archivo, out T datos)
        {
            XmlTextReader reader = new XmlTextReader(archivo);
            
            XmlSerializer ser;
            bool resultado = false;
            try
            {
                ser = new XmlSerializer(typeof(T));
                datos = (T)ser.Deserialize(reader);
                resultado = true;
            }
            catch (DirectoryNotFoundException e)
            {
                throw new ComiqueriaException("Error: Directorio no encontrado", e);
            }
            catch(Exception e)
            {
                throw new Exception("Ocurrio un error, contacte al administrador");
            }
            finally
            {
                reader.Close();
            }
            return resultado;
        }



        public static bool SerializarBinario(string archivo, T datos)
        {
            bool resultado = false;
            FileStream fs = new FileStream(archivo, FileMode.Create, FileAccess.Write);
            try
            {
                //FileStream fileStream = new FileStream(archivo, FileMode.Create);
                
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(fs, datos);
                resultado = true;
            }
            catch (DirectoryNotFoundException e)
            {
                throw new ComiqueriaException("Error: Directorio no encontrado", e);
            }
            catch (Exception e)
            {
                throw new Exception("Ocurrio un error, contacte al administrador");
            }
            finally
            {
                fs.Close();
            }
            return resultado;
        }

        public static bool DeserealizarBinario(string archivo, out T datos)
        {
            bool resultado = false;
            FileStream Fs = new FileStream(archivo, FileMode.Open, FileAccess.Read);
            try
            {
                
                
                BinaryFormatter formatter = new BinaryFormatter();
                datos = (T)formatter.Deserialize(Fs);

                resultado = true;
            }
            catch (ArgumentException e)
            {
                throw new Exception("error al intentar deserealizar", e);
            }
            catch (Exception e)
            {
                throw new Exception("Ocurrio un error, contacte al administrador");
            }
            finally
            {
                Fs.Close();
            }
            return resultado;
        }

    }
}
