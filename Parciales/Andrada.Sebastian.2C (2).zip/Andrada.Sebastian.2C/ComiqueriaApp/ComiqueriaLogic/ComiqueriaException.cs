﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    class ComiqueriaException : Exception , IArchivoTexto
    {
        public string Ruta
        {
            get
            {
                return String.Format("{0}\\log.txt", (Environment.GetFolderPath(Environment.SpecialFolder.Desktop)));
            }
        }

        public string Texto
        {
            get
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendFormat("{0}", DateTime.Now);
                Exception e = this.InnerException;
                if (!object.ReferenceEquals(e, null))
                {
                    do
                    {
                        sb.AppendLine(e.Message);
                        e = e.InnerException;
                    } while (!object.ReferenceEquals(e, null));
                }
                return sb.ToString();
            }
        }

        public ComiqueriaException(string message, Exception innerException) : base(message, innerException)
        {
            ArchivoTexto.Escribir(this, true);
        }
    }
}
