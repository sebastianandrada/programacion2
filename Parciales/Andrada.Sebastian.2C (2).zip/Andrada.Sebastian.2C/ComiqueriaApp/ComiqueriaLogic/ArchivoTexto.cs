﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    public class ArchivoTexto
    {
        public static void Escribir(IArchivoTexto archivo, bool append)
        {
            string ruta = archivo.Ruta;
            string texto = archivo.Texto;
            StreamWriter sw = new StreamWriter(ruta, append, Encoding.UTF8);
            try
            {
                sw.WriteLine(texto);
            }
            catch (Exception e)
            {
                throw new Exception();
            }
            finally
            {
                sw.Close();
            }
        }

        public static string Leer(string ruta)
        {
            string datos; 
            StreamReader sr = new StreamReader(ruta);
            try
            {
                datos = sr.ReadToEnd();
            }
            catch (Exception e)
            {
                throw new Exception();
            }
            finally
            {
                sr.Close();
            }
            return datos;
        }
    }
}
