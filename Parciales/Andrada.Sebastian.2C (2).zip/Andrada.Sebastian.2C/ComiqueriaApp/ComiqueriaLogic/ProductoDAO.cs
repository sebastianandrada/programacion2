﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    public class ProductoDAO
    {
        private static SqlCommand comando;
        private static SqlConnection conexion;
        public delegate void DelegadoABM(object sender, EventArgs e);
        public event DelegadoABM InformaResultado;

        static ProductoDAO()
        {
            string connectionStr = @"Data Source=.\SQLEXPRESS; Initial Catalog=Comiqueria; Integrated Security = True";
            try
            {
                ProductoDAO.conexion = new SqlConnection(connectionStr);
                ProductoDAO.comando = new SqlCommand();
                comando.CommandType = CommandType.Text;
                comando.Connection = conexion;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Inserta un producto en una base de datos
        /// </summary>
        /// <param name="p">producto a persistir</param>
        /// <returns>True en caso que se guarde correctamente</returns>
        public static bool Insertar(Producto p)
        {
            bool resultado = false;
            string consulta = String.Format("INSERT INTO Productos (descripcion, precio, stock) VALUES ('{0}','{1}', '{2}')", p.Descripcion, p.Precio, p.Stock);
            try
            {
                comando.CommandText = consulta;
                conexion.Open();
                comando.ExecuteNonQuery();
                resultado = true;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conexion.Close();
            }
            return resultado;
        }

        public static bool Eliminar(Producto p)
        {
            bool resultado = false;
            string consulta = String.Format("DELETE FROM Productos WHERE Codigo = '{0}'", p.Codigo);
            try
            {
                comando.CommandText = consulta;
                conexion.Open();
                comando.ExecuteNonQuery();
                resultado = true;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conexion.Close();
            }
            return resultado;
        }

        public static bool Actualizar(Producto p)
        {
            bool resultado = false;
            string consulta = String.Format("UPDATE Productos SET Descripcion = '{0}', Precio = '{1}', Stock = '{2}' WHERE Codigo = '{3}'", p.Descripcion, p.Precio, p.Stock, p.Codigo);
            try
            {
                comando.CommandText = consulta;
                conexion.Open();
                comando.ExecuteNonQuery();
                resultado = true;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conexion.Close();
            }
            return resultado;
        }

        public static List<Producto> MostrarLista()
        {
            List<Producto> articulos = new List<Producto>();
            Producto articulo;

            string consulta = String.Format("Select * from Productos");
            try
            {
                comando.CommandText = consulta;
                conexion.Open();
                SqlDataReader oDr = comando.ExecuteReader();

                while (oDr.Read())
                {
                    int codigo = int.Parse(oDr["Codigo"].ToString());
                    string descripcion = oDr["Descripcion"].ToString();
                    double precio = double.Parse(oDr["Precio"].ToString());
                    int cantidad = int.Parse(oDr["Stock"].ToString());
                    articulo = new Producto(codigo, descripcion, cantidad, precio);
                    articulos.Add(articulo);
                }
            }
            catch (Exception e)
            {
                throw e;
            }

            finally
            {
                if (conexion.State == ConnectionState.Open)
                    conexion.Close();
            }

            return articulos;
        }
    }
}
